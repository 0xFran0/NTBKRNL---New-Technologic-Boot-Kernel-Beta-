#ifndef OTHER_UTILS_H
#define OTHER_UTILS_H

/* =========================================================================
   DEFINICIÓN DE TIPOS DE DATOS PUROS (Sin depender de librerías del OS)
   ========================================================================= */
// Como no tenemos <stdint.h> ni windows.h, definimos los tipos usando los tipos nativos de GCC
typedef unsigned int   uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char  uint8_t;

// Variable global interna para contar los ticks del sistema (Usa nuestro tipo puro)
volatile uint32_t system_ticks = 0;

/* =========================================================================
   FUNCIONES DE ENTRADA / SALIDA DE BAJO NIVEL (PUERTOS)
   ========================================================================= */
// Enviar un byte a un puerto de hardware específico
inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

/* =========================================================================
   CONFIGURACIÓN DEL RELOJ DE LA PLACA MADRE (PIT 8253)
   ========================================================================= */
// El PIT corre nativamente a 1193182 Hz. Lo configuramos a 1000 Hz 
// para que cada tick del sistema equivalga exactamente a 1 milisegundo.
void iniciar_reloj() {
    uint32_t divisor = 1193182 / 1000; // Aproximadamente 1193

    // Enviar el byte de comando (Canal 0, modo onda cuadrada) al puerto 0x43
    outb(0x43, 0x36);

    // Enviar el divisor partido en bytes al puerto de datos del Canal 0 (0x40)
    outb(0x40, (uint8_t)(divisor & 0xFF));        // Byte bajo
    outb(0x40, (uint8_t)((divisor >> 8) & 0xFF)); // Byte alto
}

/* =========================================================================
   ACTUALIZADOR DEL CONTADOR DE TIEMPO
   ========================================================================= */
void actualizar_reloj() {
    system_ticks++;
}

/* =========================================================================
   LA FUNCIÓN Sleep() PURA PARA TU KERNEL
   ========================================================================= */
// Detiene la ejecución durante los milisegundos indicados
// suspendiendo la CPU con 'hlt' para no quemar recursos del host.
void Sleep(uint32_t milisegundos) {
    uint32_t ticks_objetivo = system_ticks + milisegundos;

    while (system_ticks < ticks_objetivo) {
        // Instrucción en Assembly puro para dormir la CPU temporalmente
        // hasta que el hardware mande la siguiente señal eléctrica.
        __asm__ volatile("hlt");
    }
}

#endif
