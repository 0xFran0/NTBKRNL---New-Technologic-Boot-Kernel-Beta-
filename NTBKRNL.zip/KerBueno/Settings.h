#ifndef SETTINGS_H
#define SETTINGS_H

/* =========================================================================
   DEFINICIÓN DE TIPOS DE DATOS PUROS
   ========================================================================= */
typedef unsigned int uint32_t;

/* =========================================================================
   LA FUNCIÓN DEL KERNEL: SET_EAX
   ========================================================================= */
/**
 * Fuerza a la CPU a cargar cualquier dato de 32 bits en el registro EAX.
 * Puede recibir:
 *  - Un número entero crudo          -> SET_EAX((void=)100);
 *  - La dirección de una variable    -> SET_EAX((void*)&mi_variable);
 *  - La estructura de un PID/Proceso -> SET_EAX((void*)&tabla_sistema);
 */
inline void SET_EAX(void* dato) {
    uint32_t valor = (uint32_t)dato;

    // Código Assembly en línea para GCC (Modo independiente)
    __asm__ volatile(
        "movl %0, %%eax" 
        : 
        : "r" (valor) 
        : "eax" // Le avisa al compilador que modificamos EAX para que no rompa el código
    );
}

#endif
