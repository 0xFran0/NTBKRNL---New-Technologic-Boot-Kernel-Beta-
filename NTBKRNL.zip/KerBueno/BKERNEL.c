/* =========================================================================
   1. INCLUDES DEL SISTEMA (Headers Autónomos "Header-Only", Cero archivos .c)
   ========================================================================= */
#include "Process.h"     // Tu PCB y tu función crear_proceso() estática inline
#include "Utils.h"       // Contiene controladores outb/inb y tu Read(Cosa, Direccion)
#include "OtherUtils.h"  // Contiene tu Sleep() real basado en hlt sin quemar CPU
#include "Settings.h"    // Contiene tu función Set(Cosa, Direccion) para inyectar datos

/* =========================================================================
   2. TIPOS DE DATOS CONFIGURADOS PARA UEFI DE 64 BITS NATIVO
   ========================================================================= */
typedef unsigned char      u8;
typedef unsigned int       u32;
typedef unsigned long long u64;

#define KERNEL_API __attribute__((ms_abi)) // Convención de llamadas x64 de Windows/UEFI

typedef struct { u32* base_lineal; u64 ancho; u64 alto; u64 pitch; } ParametrosVideoGPU;
typedef struct { u64 direccion_base; u64 longitud; u32 tipo; u32 atributos; } DescriptorRAM;
typedef struct { DescriptorRAM* registros; u64 total_bloques; } MapaRAM;

typedef struct __attribute__((aligned(64))) {
    u64 rip; u64 rsp; u64 cr3; const char* msg;
} RegistroCrash;

/* =========================================================================
   3. CONFIGURACIÓN ESTRATÉGICA DE INTK (INTERRUPT KERNEL HANDLER)
   ========================================================================= */
/* 
   ================================================================================
   📢 NOTA ARQUITECTÓNICA PARA EL REPOSITORIO DE GITHUB:
   
   Si quieres que tu OS sea COMERCIAL, crea INTK para que, por ejemplo, una impresora 
   llame a INTK cuando necesite enviar datos, permitiendo al sistema despachar 
   la interrupción de forma asíncrona. 
   Pero si no, y quieres hacerlo EN SECO, ¡está perfecto! Puedes omitir INTK y hacer 
   que el núcleo lea el periférico directamente usando tus funciones nativas Read() 
   de "Utils.h" en el bucle principal.
   ================================================================================
*/
void INTK(u32 vector_interrupcion, void* datos_periferico) {
    // Si una impresora llama aquí de forma comercial, el núcleo procesa el evento
    Set("LAST_HARDWARE_INTERRUPT", (void*)(u64)vector_interrupcion);
}

/* =========================================================================
   4. FUENTE BITMAP BINARIA INTEGRADA PARA LA GPU (8x16 Píxeles)
   ========================================================================= */
static const u8 fuente_binaria = {
    ['K']={0x42,0x44,0x48,0x70,0x48,0x44,0x42,0x42}, ['E']={0x7E,0x40,0x40,0x78,0x40,0x40,0x40,0x7E},
    ['R']={0x7C,0x42,0x42,0x7C,0x48,0x44,0x42,0x42}, ['N']={0x42,0x62,0x52,0x4A,0x46,0x42,0x42,0x42},
    ['L']={0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x7E}, [':']={0x00,0x18,0x18,0x00,0x00,0x18,0x18},
    ['1']={0x10,0x30,0x10,0x10,0x10,0x10,0x10,0x38}, ['0']={0x3C,0x46,0x4A,0x52,0x62,0x62,0x42,0x3C},
    [' ']={0x00,0x00,0x00,0x00,0x00}, ['S']={0x3C,0x42,0x40,0x3C,0x02,0x02,0x42,0x3C},
    ['G']={0x3C,0x42,0x40,0x40,0x4E,0x42,0x42,0x3C}, ['U']={0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C},
    ['D']={0x78,0x44,0x42,0x42,0x42,0x42,0x44,0x78}, ['O']={0x3C,0x42,0x42,0x42,0x42,0x42,0x42,0x3C},
    ['I']={0x3E,0x08,0x08,0x08,0x08,0x08,0x08,0x3E}, ['M']={0x42,0x66,0x5A,0x42,0x42,0x42,0x42,0x42},
    ['T']={0x7E,0x08,0x08,0x08,0x08,0x08,0x08,0x08}, ['A']={0x18,0x24,0x42,0x42,0x7E,0x42,0x42,0x42},
    ['B']={0x7C,0x42,0x42,0x7C,0x42,0x42,0x42,0x7C}, ['P']={0x7C,0x42,0x42,0x7C,0x40,0x40,0x40,0x40}
};

/* =========================================================================
   5. CONTROLADOR GRÁFICO (Inyección Directa en el Lienzo de la GPU)
   ========================================================================= */
static u32* vram_gpu = 0;
static u64  g_ancho = 0, g_alto = 0, g_pitch = 0;
static u64  cur_x = 40, cur_y = 40, max_ram = 0;

inline void gpu_pixel(u64 x, u64 y, u32 col) {
    if (x < g_ancho && y < g_alto) vram_gpu[x + (y * (g_pitch / 4))] = col;
}

void gpu_limpiar(u32 col) {
    u64 total = (g_pitch / 4) * g_alto;
    for (u64 i = 0; i < total; i++) vram_gpu[i] = col;
}

// Escritor híbrido: Si encuentra un prefijo "0x", decodifica el número hexadecimal en pantalla
void k_escribir(const char* txt, u64 val_hex, u32 col) {
    int i = 0;
    while (txt[i] != '\0') {
        if (txt[i] == '\n') { cur_x = 40; cur_y += 20; i++; continue; }
        
        if (txt[i] == '0' && txt[i+1] == 'x') {
            k_escribir("0X", 0, col);
            for (int n = 0; n < 16; n++) {
                int shift = (15 - n) * 4;
                char hex_digit = "0123456789ABCDEF"[(val_hex >> shift) & 0xF];
                for (int f = 0; f < 16; f++) {
                    u8 bits = fuente_binaria[(u8)hex_digit][f];
                    for (int c = 0; c < 8; c++) if (bits & (0x80 >> c)) gpu_pixel(cur_x + c, cur_y + f, col);
                }
                cur_x += 10;
            }
            i += 2; continue;
        }
        for (int f = 0; f < 16; f++) {
            u8 bits = fuente_binaria[(u8)txt[i]][f];
            for (int c = 0; c < 8; c++) if (bits & (0x80 >> c)) gpu_pixel(cur_x + c, cur_y + f, col);
        }
        cur_x += 10; i++;
    }
}

void video_render_cyber_matrix(u32 desplazamiento_lineas) {
    u32 color_linea_vertical = 0x1A2238; 
    u32 color_linea_horizontal = 0x004466; 

    for (u64 y = 200; y < 450; y += 20) {
        u64 posicion_y_dinamica = y + (desplazamiento_lineas % 20);
        for (u64 x = 0; x < g_ancho; x++) gpu_pixel(x, posicion_y_dinamica, color_linea_horizontal);
    }
    for (u64 x = 0; x < g_ancho; x += 40) {
        for (u64 y = 200; y < 450; y++) gpu_pixel(x, y, color_linea_vertical);
    }
}

/* =========================================================================
   6. DIAGNÓSTICO AVANZADO: PANTALLA AZUL DE LA MUERTE (BSOD)
   ========================================================================= */
void k_panic_bsod(RegistroCrash* c) {
    __asm__ volatile("cli"); // Apagar hilos de la CPU
    gpu_limpiar(0x0000AA);   // Teñir de azul el monitor
    cur_x = 50; cur_y = 50;

    k_escribir("TBKRNL_FATAL_EXCEPTION_IN_BARE_METAL_64\n", 0, 0xFFFFFF);
    k_escribir("EL NUCLEO SE APAGO DE MANERA SEGURA PARA PROTEGER EL HARDWARE.\n\n", 0, 0xFFFFFF);
    k_escribir("MENSAJE DEL CRASH: ", 0, 0xFFFFFF); k_escribir(c->msg, 0, 0x00FFFF); k_escribir("\n", 0, 0xFFFFFF);
    
    // Volcado real de registros físicos de la CPU en la pantalla azul
    k_escribir("REGISTRO INSTRUCCION RIP: 0x", c->rip, 0xFFFF00); k_escribir("\n", 0, 0xFFFFFF);
    k_escribir("REGISTRO PILA CRITICA RSP: 0x", c->rsp, 0xFFFF00); k_escribir("\n", 0, 0xFFFFFF);
    k_escribir("REGISTRO DIRECTORIO  CR3: 0x", c->cr3, 0xFFFF00); k_escribir("\n", 0, 0xFFFFFF);
    k_escribir("TECHO DE MEMORIA RAM REAL: 0x", max_ram, 0xFFFF00); k_escribir("\n\n", 0, 0xFFFFFF);

    // Guardar el log del crash usando tu framework de Settings y Utils
    k_escribir("SALVANDO METADATOS DEL CHOQUE VIA SETTINGS...\n", 0, 0x00FF88);
    Set("CRASH_DUMP_ADDR", (void*)0x500000); 
    
    k_escribir("VERIFICANDO LOG FISICO VIA UTILS: ", 0, 0x00FF88);
    u64 estado_bus = (u64)Read("HARDWARE_BUS_STATUS", (void*)0x500000); 
    if (estado_bus == 0) k_escribir("LOG_COMPLETO_OK\n", 0, 0x00FF88);

    k_escribir("\nSISTEMA TOTALMENTE CONGELADO. REINICIE EL EQUIPO.", 0, 0xFFFFFF);

    while (1) { __asm__ volatile("hlt"); }
}

/* =========================================================================
   7. PUNTO DE ENTRADA ABSOLUTO DE TU HARDWARE (TBKRNL)
   ========================================================================= */
KERNEL_API void ejecutar_kernel_principal(ParametrosVideoGPU* gpu, MapaRAM* ram) {
    vram_gpu = gpu->base_lineal; g_ancho = gpu->ancho; g_alto = gpu->alto; g_pitch = gpu->pitch;
    gpu_limpiar(0x111116);

    // Calcular el mapa de la RAM física real de la PC
    for (u64 i = 0; i < ram->total_bloques; i++) {
        if (ram->registros[i].tipo == 7) {
            u64 fin = ram->registros[i].direccion_base + ram->registros[i].longitud;
            if (fin > max_ram) max_ram = fin;
        }
    }

    k_escribir("TBKRNL CORE 64 OPERATIVO\n", 0, 0x00FF88);

    // --- ENLAZANDO TU LOGICA DE PROCESS.H ---
    // Usamos tu función estática inline del header para probar el planificador en seco
    Proceso tarea_core = crear_proceso("TB_CORE");
    Proceso tarea_gpu  = crear_proceso("TB_GPU");

    k_escribir("PROCESO 1 CREADO - PID: ", 0, 0xFFFFFF);
    k_escribir(tarea_core.nombre, 0, 0x00FFFF); 
    
    k_escribir("\nPROCESO 2 CREADO - PID: ", 0, 0xFFFFFF);
    k_escribir(tarea_gpu.nombre, 0, 0x00FFFF); k_escribir("\n\n", 0, 0xFFFFFF);

    // Espera controlada por hardware usando tu OtherUtils.h
    Sleep(500);

    // Renderizar la animación en la GPU
    for (u32 frame = 0; frame < 3; frame++) {
        video_render_cyber_matrix(frame * 5);
        Sleep(150); 
    }

    k_escribir("\nEJECUCION FINALIZADA. DISPARANDO BSOD DE DIAGNOSTICO...\n", 0, 0x00FF88);
    Sleep(400);

    // Simular error crítico de hardware y vaciar registros en la BSOD
    RegistroCrash crash;
    __asm__ volatile("movq %%rsp, %0" : "=r"(crash.rsp));
    __asm__ volatile("movq %%cr3, %0" : "=r"(crash.cr3));
    crash.rip = (u64)ejecutar_kernel_principal;
    crash.msg = "EXCEPTION_HARDWARE_BUS_COLLAPSE_METADATA_INVALID";
    
    k_panic_bsod(&crash);
}
