#ifndef PROCESS_H
#define PROCESS_H

// Estructura básica para controlar un proceso (Process Control Block - PCB)
typedef struct {
    int pid;            // Identificador único del proceso
    int estado;         // 0 = Detenido, 1 = Corriendo
    char nombre[10];    // Nombre descriptivo del proceso
} Proceso;

// Contador global para asegurar que cada PID sea único
int siguiente_pid = 0;

// Función del kernel para inicializar y asignar un PID a un nuevo proceso
Proceso crear_proceso(char* nombre_proceso) {
    Proceso nuevo;
    
    // Asigna el PID actual e incrementa el contador para el próximo proceso
    nuevo.pid = siguiente_pid++;
    nuevo.estado = 1; // Estado: Corriendo
    
    // Copiar el nombre de forma segura y manual (sin usar librerías externas)
    int i = 0;
    while (nombre_proceso[i] != '\0' && i < 9) {
        nuevo.nombre[i] = nombre_proceso[i];
        i++;
    }
    nuevo.nombre[i] = '\0';
    
    return nuevo;
}

#end