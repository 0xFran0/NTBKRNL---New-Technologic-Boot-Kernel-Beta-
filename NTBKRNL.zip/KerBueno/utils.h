#ifndef UTILS_H
#define UTILS_H

// Estructura necesaria para la tabla de procesos del sistema
typedef struct {
    int pid;
    const char* nombre;
} Proceso;

// Lee un byte directo desde un puerto de hardware x86
inline unsigned char inb(unsigned short port) {
    unsigned char result;
    __asm__ volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

// Escribe un byte directo hacia un puerto de hardware x86
inline void outb(unsigned short port, unsigned char data) {
    __asm__ volatile("outb %0, %1" : : "a"(data), "Nd"(port));
}

// Tabla de traducción física del teclado (CP437)
// Mapea los scancodes de hardware a caracteres ASCII estándar e IBM extendidos
static const char teclado_mapa[128] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
  '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']', '\n',
    0,  'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '\xA5', 0,  '`',
    0, '\\', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/',   0, '*',
    0,  ' ',   0
};

// Captura una tecla del hardware (Bloqueante por si la requieres en otras áreas)
char get_key() {
    unsigned char scancode = 0;
    while (1) {
        // Verificar si el estado del teclado (puerto 0x64) tiene datos listos
        if (inb(0x64) & 1) {
            scancode = inb(0x60);
            // Si el bit 7 es 0, la tecla fue presionada (Make Code)
            if (!(scancode & 0x80) && scancode < 128) {
                char letra = teclado_mapa[scancode];
                if (letra != 0) return letra;
            }
        }
    }
    return '?';
}

// Función Read estilo Bash: captura la tecla y la asigna a la variable
void Read(char *variable_destino) {
    *variable_destino = get_key();
}

// Delay nativo por software (Ciclos puros de CPU con NOP)
// No requiere que la IDT ni el PIT estén configurados para medir el tiempo
void sleep_nativo(unsigned int ciclos) {
    for (volatile unsigned int i = 0; i < ciclos * 10000; i++) {
        __asm__ volatile("nop");
    }
}

#endif
